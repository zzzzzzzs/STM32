#ifndef __FUNC_H
#define __FUNC_H

#ifdef __cplusplus
extern "C" {
#endif

#include "yg.h"
#include "nrf24l01.h"
#include "mechanical_arm.h"
#include "mpu6050.h" 
#include "inv_mpu.h"
#include "inv_mpu_dmp_motion_driver.h"
#include "report_mpu.h"
#include "yg_key.h"
#include "yg_wdg.h"

typedef struct
{
	short aacx,aacy,aacz;//���ٶȴ�����ԭʼ����
	short gyrox,gyroy,gyroz;//�����Ǵ�����ԭʼ����
} _filter;

typedef struct
{
	int16_t turntable;
	int16_t big;
	int16_t small;
	int16_t small_max;
	int16_t small_min;
	int16_t wrist;
	int16_t claw;
} _servo_ang;

extern _filter 		filter_data;
extern _filter 		raw_data;
extern _servo_ang	servo_ang;



void Slide_Filter(_filter *filter_in, _filter *filter_out);
void setup();
void task();

#ifdef __cplusplus
}
#endif


#endif

