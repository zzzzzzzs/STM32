#ifndef __MECHANICAL_H
#define __MECHANICAL_H

#ifdef __cplusplus
extern "C" {
#endif

	
#include "yg_pwm.h"
#include "yg.h"
	

class Arm:public Pwm
{
	public:
		Arm(Gpio *port_pin);
		void servo_control(uint16_t angle);
};

void arm_init(uint16_t period, uint16_t prescaler);


extern Arm	arm_turntable;
extern Arm	arm_big;
extern Arm	arm_small;
extern Arm 	arm_wrist;
extern Arm 	arm_claw;



	
	
	
#ifdef __cplusplus
}
#endif

#endif

