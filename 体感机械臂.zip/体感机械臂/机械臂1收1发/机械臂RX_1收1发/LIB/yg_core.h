#ifndef __YG_CORE_H
#define __YG_CORE_H

#ifdef __cplusplus
extern "C"{
#endif

	
#include "usart.h"
#include "delay.h"
#include "yg_gpio.h"
#include "yg_adc.h"
void yg_init();


#ifdef __cplusplus
}
#endif

#endif

