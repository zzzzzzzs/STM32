#include "yg_key.h"

/*
*@brief		������
*@param		
*@retval
*/
Key::Key(Gpio *port_pin, PIN_MODE pin_mode):port_pin(port_pin), pin_mode(pin_mode)
{
	GPIO_InitTypeDef GPIO_InitStruc;
	
	switch((uint32_t)port_pin->port)
	{
		case (uint32_t)GPIOA_BASE:
			RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
		break;
		
		case (uint32_t)GPIOB_BASE:
			RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
		break;
		
		case (uint32_t)GPIOC_BASE:
			RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);
		break;
		
		case (uint32_t)GPIOD_BASE:
			RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOD, ENABLE);
		break;
		
		case (uint32_t)GPIOE_BASE:
			RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOE, ENABLE);
		break;
		
		case (uint32_t)GPIOF_BASE:
			RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOF, ENABLE);
		break;
		
		case (uint32_t)GPIOG_BASE:
			RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOG, ENABLE);
		break;
	}
	
	switch((uint8_t)pin_mode)
	{
		case IPD:
			GPIO_InitStruc.GPIO_Mode = GPIO_Mode_IPD;
		break;
		
		case IPU:
			GPIO_InitStruc.GPIO_Mode = GPIO_Mode_IPU;
		break;
		default:
			GPIO_InitStruc.GPIO_Mode = GPIO_Mode_IPU;
		break;
	}
	GPIO_InitStruc.GPIO_Pin = port_pin->pin;
	GPIO_InitStruc.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(port_pin->port, &GPIO_InitStruc);
}
/*
*@brief		˽�к���  �õ�����
*@param		
*@retval
*/
PIN_ID_t Key::get_pin_id()
{
	uint8_t temp1, temp2;//�������ŵĹ�����
	pin_id = (PIN_ID_t)(temp1*16 + temp2);
	return pin_id;
}

/*
*@brief		
*@param		
*@retval
*/
uint8_t Key::key_press()
{
	switch((uint8_t)pin_mode)
	{
		case IPD://��������
			if(port_pin->read() == 1)
			{
				delay_ms(10);
				return PRESS;
			}
		break;
		case IPU:
			if(port_pin->read() == 0)
			{
				delay_ms(10);
				return PRESS;
			}
		break;
	}
	return RELEASE;//�ɿ�
}

//PIN_ID_t key_scan()
//{
//	static key_sign = 1;
//	if(key_sign && (key1 == PRESS  ))
//	{
//		delay_ms(10);
//		key_sign = 0;
//	}
//	else if(key1 == RELEASE && )
//		key_sign = 1;
//	return ;
//}








