#include "yg_pwm.h"

#define TIMxCH1 0x01//ͨ��
#define TIMxCH2 0x02
#define TIMxCH3 0x03
#define TIMxCH4 0x04

/*
*@brief		pwm������
*@param		
*@retval	nono
*/
Pwm::Pwm(Gpio *pwm_port_pin)
{
	this->pwm_port_pin = pwm_port_pin;
}

/*
*@brief		��ʼ��
*@param		
*@retval
*/
void Pwm::init(uint16_t period, uint16_t prescaler, uint8_t Polar)
{
	pwm_port_pin->mode(AF_PP);
	com_init(pwm_port_pin);
	base_init(period, prescaler);
	mode(Polar);
	start();
}
/*
*@brief		��ʼ��
*@param		
*@retval
*/

void Pwm::set_duty(uint16_t duty)
{
	switch(pwm_ch)
	{
		case TIMxCH1:
			TIM_SetCompare1(TIMx, duty);
		break;
		case TIMxCH2:
			TIM_SetCompare2(TIMx, duty);
		break;
		case TIMxCH3:
			TIM_SetCompare3(TIMx, duty);
		break;
		case TIMxCH4:
			TIM_SetCompare4(TIMx, duty);
		break;
	}
}
/*
*@brief		�õ��˿�
*@param		
*@retval	port
*/
GPIO_TypeDef *Pwm::get_port()
{
	return pwm_port_pin->port;
}


/*
*@brief		�õ�����
*@param		
*@retval	pin
*/
uint16_t Pwm::get_pin()
{
	return pwm_port_pin->pin;
}


/*
*@brief		˽��	��ʼ��
*@param		
*@retval	none
*/
void Pwm::base_init(uint16_t period, uint16_t prescaler)
{
	TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
	if(rcc == RCC_APB2Periph_TIM1 || rcc == RCC_APB2Periph_TIM8)
	{
		RCC_APB2PeriphClockCmd(rcc, ENABLE);
		TIM_CtrlPWMOutputs(TIMx, ENABLE);
	}
	else
		RCC_APB1PeriphClockCmd(rcc, ENABLE);
	
	TIM_TimeBaseStructure.TIM_Period = period - 1; 
	TIM_TimeBaseStructure.TIM_Prescaler = prescaler - 1;
	TIM_TimeBaseStructure.TIM_ClockDivision = 0;//���ָ� 
	TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Down;  
	TIM_TimeBaseInit(TIMx, &TIM_TimeBaseStructure); 
	
//	TIM_ARRPreloadConfig(TIMx, ENABLE);//Ӱ�ӼĴ���
}

/*
*@brief		˽��	���ŵ���Ϣ����
*@param		
*@retval	none
*/
void Pwm::com_init(Gpio* pwm_port_pin)
{

	if(pwm_port_pin->port == GPIOA)
	{
		switch(pwm_port_pin->pin)
		{
			//TIM2
			case GPIO_Pin_0:
				TIMx = TIM2;
				rcc = RCC_APB1Periph_TIM2;
				pwm_ch = TIMxCH1;
			break;
			case GPIO_Pin_1:
				TIMx = TIM2;
				rcc = RCC_APB1Periph_TIM2;
				pwm_ch = TIMxCH2;
			break;
			case GPIO_Pin_2:
				TIMx = TIM2;
				rcc = RCC_APB1Periph_TIM2;
				pwm_ch = TIMxCH3;
			break;
			case GPIO_Pin_3:
				TIMx = TIM2;
				rcc = RCC_APB1Periph_TIM2;
				pwm_ch = TIMxCH4;
			break;
			//TIM3
			case GPIO_Pin_6:
				TIMx = TIM3;
				rcc = RCC_APB1Periph_TIM3;
				pwm_ch = TIMxCH1;
			break;
			case GPIO_Pin_7:
				TIMx = TIM3;
				rcc = RCC_APB1Periph_TIM3;
				pwm_ch = TIMxCH2;
			break;
			//TIM1
			case GPIO_Pin_8:
				TIMx = TIM1;
				rcc = RCC_APB2Periph_TIM1;
				pwm_ch = TIMxCH1;
			break;
			case GPIO_Pin_9:
				TIMx = TIM1;
				rcc = RCC_APB2Periph_TIM1;
				pwm_ch = TIMxCH2;
			break;
			case GPIO_Pin_10:
				TIMx = TIM1;
				rcc = RCC_APB2Periph_TIM1;
				pwm_ch = TIMxCH3;
			break;
			case GPIO_Pin_11:
				TIMx = TIM1;
				rcc = RCC_APB2Periph_TIM1;
				pwm_ch = TIMxCH4;
			break;
		}
	}
	if(pwm_port_pin->port == GPIOB)
	{
		switch(pwm_port_pin->pin)
		{
			//TIM4
			case GPIO_Pin_6:
				TIMx = TIM4;
				rcc = RCC_APB1Periph_TIM4;
				pwm_ch = TIMxCH1;
			break;
			case GPIO_Pin_7:
				TIMx = TIM4;
				rcc = RCC_APB1Periph_TIM4;
				pwm_ch = TIMxCH2;
			break;
			case GPIO_Pin_8:
				TIMx = TIM4;
				rcc = RCC_APB1Periph_TIM4;
				pwm_ch = TIMxCH3;
			break;
			case GPIO_Pin_9:
				TIMx = TIM4;
				rcc = RCC_APB1Periph_TIM4;
				pwm_ch = TIMxCH4;
			break;
			//TIM3
			case GPIO_Pin_0:
				TIMx = TIM3;
				rcc = RCC_APB1Periph_TIM3;
				pwm_ch = TIMxCH3;
			break;
			case GPIO_Pin_1:
				TIMx = TIM3;
				rcc = RCC_APB1Periph_TIM3;
				pwm_ch = TIMxCH4;
			break;
		}
	}
}

/*
*@brief		˽��	PWMģʽ����
*@param		
*@retval	none
*/
void Pwm::mode(uint8_t Polar)
{
	TIM_OCInitTypeDef  TIM_OCInitStructure;
	
	if(Polar == HIGH)
		TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;
	else if(Polar == LOW)
		TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_Low;

	TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM2;
	TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
	switch(pwm_ch)
	{
		case	TIMxCH1: 
			TIM_OC1Init(TIMx, &TIM_OCInitStructure);
			TIM_OC1PreloadConfig(TIMx, TIM_OCPreload_Enable);
		break;
		case	TIMxCH2: 
			TIM_OC2Init(TIMx, &TIM_OCInitStructure);
			TIM_OC2PreloadConfig(TIMx, TIM_OCPreload_Enable);
		break;
		case	TIMxCH3: 
			TIM_OC3Init(TIMx, &TIM_OCInitStructure);
			TIM_OC3PreloadConfig(TIMx, TIM_OCPreload_Enable);
		break;
		case	TIMxCH4: 
			TIM_OC4Init(TIMx, &TIM_OCInitStructure);
			TIM_OC4PreloadConfig(TIMx, TIM_OCPreload_Enable);
		break;
	}
}



/*
*@brief		˽��	PWMģʽ����
*@param		
*@retval	none
*/
void Pwm::start()
{
	TIM_Cmd(TIMx, ENABLE);
}


/*
*@brief		˽��	PWMģʽ����
*@param		
*@retval	none
*/
void Pwm::stop()
{
	TIM_Cmd(TIMx, DISABLE);
}



