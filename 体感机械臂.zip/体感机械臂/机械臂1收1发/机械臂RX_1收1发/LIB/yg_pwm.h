#ifndef __YG_PWM_H
#define __YG_PWM_H

#ifdef __cplusplus
extern "C" {
#endif

#define HIGH		1
#define LOW			0
	
#include "yg_gpio.h"

/*
	��ʱ�������б�
	ͨ��	CH1		CH2		CH3		CH4
	TIM1	PA8.	PA9.	PA10	PA11
	TIM2	PA0		PA1		PA2		PA3
	TIM3	PA6.	PA7.	PB0		PB1
	TIM4	PB6		PB7		PB8		PB9
	
*/

class Pwm
{
	public:
		Pwm(Gpio *pwm_pin);
		void init(uint16_t period, uint16_t prescaler, uint8_t Polar = LOW);
		void set_duty(uint16_t duty);//
		GPIO_TypeDef *get_port();
		uint16_t	get_pin();
		void start();//��ʱ��ʹ��
		void stop();//��ʱ��ʧ��
	private:
		void base_init(uint16_t period, uint16_t prescaler);
		void com_init(Gpio *pwm_pin);
		void mode(uint8_t Polar);
		void set_freq(uint16_t freq);
	
		uint16_t 		freq;
		Gpio 				*pwm_port_pin;
		TIM_TypeDef	*TIMx;
		uint32_t		rcc;
		uint8_t			pwm_ch;
		
};


#ifdef __cplusplus
}
#endif

#endif





//#include "func.h"


//Pwm pwm1(&PA6);
//void setup()
//{
//	yg_init();
//	pwm1.init(1000000 / 1000, 72);
//}

//int main()
//{
//	setup();
//	while(1)
//	{
//			pwm1.set_duty(100);
//	}
//}


