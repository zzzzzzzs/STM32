#include "yg_timer.h"



/*
*@brief			������	
*@param			TIMx
*@retval		none
*/
Timer::Timer(TIM_TypeDef *TIMx)
{
	this->TIMx = TIMx;
}
/*
*@brief			��ʱ����ʼ��
*@param			
*@retval		none
*/
void Timer::init(uint16_t period, uint16_t prescaler)
{
	base_init(period, prescaler);
	start();
}

/*
*@brief			��ʱ����ʼ��
*@param			
*@retval		none
*/
void Timer::init(uint16_t period)
{
	base_init(10000 / period, 7200);
	start();
}

/*
*@brief			˽�к�������ʼ���ײ�		
*@param			
*@retval		none
*/
void Timer::base_init(uint16_t period, uint16_t prescaler)
{
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStructure;
	NVIC_InitTypeDef NVIC_InitStructure;

	TIM_DeInit(TIMx);
	switch((uint32_t)TIMx)
	{
		case (uint32_t)TIM1:
			RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM1, ENABLE);
			//�˴���ͨ�ö�ʱ����һ��	���ƶ�ʱ��������ٴβ���һ���ж�
			nvic_ch = TIM1_UP_IRQn;
			break;
		case	(uint32_t)TIM2:
			RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);
			nvic_ch = TIM2_IRQn;
			break;
		case	(uint32_t)TIM3:
			RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE);
			nvic_ch = TIM3_IRQn;
			break;
		case	(uint32_t)TIM4:
			RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM4, ENABLE);
			nvic_ch = TIM4_IRQn;
			break;
#if defined	(STM32F10X_HD)
		case	(uint32_t)TIM5:
			RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM5, ENABLE);
			nvic_ch = TIM5_IRQn;
			break;
		case	(uint32_t)TIM6:
			RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM6, ENABLE);
			nvic_ch = TIM6_IRQn;
			break;
		case	(uint32_t)TIM7:
			RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM7, ENABLE);
			nvic_ch = TIM7_IRQn;
			break;
#endif		
	}
	TIM_InternalClockConfig(TIMx);
	
	TIM_TimeBaseInitStructure.TIM_ClockDivision = TIM_CKD_DIV1;
	TIM_TimeBaseInitStructure.TIM_CounterMode = TIM_CounterMode_Up;
	TIM_TimeBaseInitStructure.TIM_Period = period - 1;
	TIM_TimeBaseInitStructure.TIM_Prescaler = prescaler - 1;
	
	TIM_TimeBaseInit(TIMx, &TIM_TimeBaseInitStructure);
	TIM_ARRPreloadConfig(TIMx, ENABLE);	//����ARR�Ĵ���ʹ��Ӱ�ӼĴ���
	TIM_ITConfig(TIMx, TIM_IT_Update, ENABLE);
	
	
	NVIC_InitStructure.NVIC_IRQChannel = nvic_ch;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
	
	NVIC_Init(&NVIC_InitStructure);

}

/*
*@brief			ʹ�ܶ�ʱ��		
*@param			none
*@retval		none
*/
void Timer::start()
{
	TIM_Cmd(TIMx, ENABLE);
}


/*
*@brief			ʧ�ܶ�ʱ��
*@param			none
*@retval		none
*/

void Timer::stop()
{
	TIM_Cmd(TIMx, DISABLE);
}


//uint32_t	tim3Count = 0;
//uint32_t 	sign = 0;
//void TIM3_IRQHandler(void)
//{
//	if(TIM_GetITStatus(TIM3, TIM_IT_Update) == SET)
//	{
//		tim3Count++;
//		TIM_ClearITPendingBit(TIM3, TIM_IT_Update);
//	}
//}



//extern "C" void TIM1_UP_IRQHandler(void)
//{
//	if(TIM_GetITStatus(TIM1, TIM_IT_Update) == SET)
//	{
//		PC2.toggle();
//		TIM_ClearITPendingBit(TIM1, TIM_IT_Update);
//	}
//}
