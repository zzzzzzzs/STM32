#include "func.h"

int main()
{
	setup();
	servo_ang.claw = 90;
	
	while(1)
	{
		task();
	}
}

