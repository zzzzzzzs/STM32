#include "func.h"

extern "C" void TIM3_IRQHandler(void)
{
	if(TIM_GetITStatus(TIM3, TIM_IT_Update) == SET)
	{
		PC2.toggle();
		TIM_ClearITPendingBit(TIM3, TIM_IT_Update);
	}
}

Timer timer3(TIM3);

void setup()
{
	yg_init();
	timer3.init(1);
	PC1.mode(Out_PP);
	PC2.mode(Out_PP);
	PC1.set();
	PC2.set();
}

int main()
{
	int a;
	setup();
	while(1)
	{
		PC1.toggle();
		delay_ms(100);
	}
}

