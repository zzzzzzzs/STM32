#include "mechanical_arm.h"

Arm	arm_turntable(&PB0);
Arm arm_big(&PB1);//80-180
Arm	arm_small(&PB6);
Arm arm_wrist(&PB7);
Arm arm_claw(&PB8);//50-110

Arm::Arm(Gpio *port_pin):Pwm(port_pin)
{
	
}

void Arm::servo_control(uint16_t angle)
{
	uint16_t duty;
	duty = 50 + 1.1 * angle;
	if(duty <= 50) duty = 50;//0
	if(duty >= 250) duty = 250;//180
	if(get_port() == GPIOB)
	{
		switch(get_pin())
		{
			case GPIO_Pin_0://arm_turntable
				set_duty(duty);
			break;
			case GPIO_Pin_1://arm_big 	80-180
				if(duty>=250)	duty = 250;
				if(duty<=138) duty = 138;
				set_duty(duty);
			break;
			case GPIO_Pin_6://arm_small
				set_duty(duty);
			break;
			case GPIO_Pin_7://arm_wrist
				set_duty(duty);
			break;
			case GPIO_Pin_8://arm_claw
				set_duty(duty);
			break;
		}
	}
}

void arm_init(uint16_t period, uint16_t prescaler)
{
	arm_turntable.init(period, prescaler);
	arm_big.init(period, prescaler);
	arm_small.init(period, prescaler);
	arm_claw.init(period, prescaler);
	arm_wrist.init(period, prescaler);
}




