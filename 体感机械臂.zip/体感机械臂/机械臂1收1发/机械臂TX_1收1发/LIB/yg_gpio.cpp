#include "yg_gpio.h"

/*
	@brief	��ʼ��GPIO,������
	@param	GPIOA~GPIOG
	@param	GPIO_Pin0~GPIO_Pin15
	@retval	nono
*/
Gpio::Gpio(GPIO_TypeDef *port, uint16_t pin)
{
	uint8_t temp1, temp2;//�������ŵĹ�����
	this->port = port;
	this->pin = pin;
	switch((uint32_t)port)
	{
		case(uint32_t)GPIOA_BASE:
			temp1 = 0;
		break;
		
		case(uint32_t)GPIOB_BASE:
			temp1 = 1;
		break;
		
		case(uint32_t)GPIOC_BASE:
			temp1 = 2;
		break;
		
		case(uint32_t)GPIOD_BASE:
			temp1 = 3;
		break;
		
		case(uint32_t)GPIOE_BASE:
			temp1 = 4;
		break;
		
		case(uint32_t)GPIOF_BASE:
			temp1 = 5;
		break;
		
		case(uint32_t)GPIOG_BASE:
			temp1 = 6;
		break;
		
		default:
			temp1 = 0;
		break;
	}
	for(int i = 0; i <= 15; i++)
	{
		if((this->pin >> i) == 0)
		{
			temp2 = i - 1;
			break;
		}
	}
	this->id = (PIN_ID_t)(temp1*16 + temp2);
}

/*
*@brief	��������ģʽ
*@param	PIN_MODE
*@retval	none
*/
void Gpio::mode(PIN_MODE mode)
{
	GPIO_InitTypeDef GPIO_InitStruc;
	
	switch((uint32_t)this->port)
	{
		case (uint32_t)GPIOA_BASE:
			RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
		break;
		
		case (uint32_t)GPIOB_BASE:
			RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
		break;
		
		case (uint32_t)GPIOC_BASE:
			RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);
		break;
		
		case (uint32_t)GPIOD_BASE:
			RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOD, ENABLE);
		break;
		
		case (uint32_t)GPIOE_BASE:
			RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOE, ENABLE);
		break;
		
		case (uint32_t)GPIOF_BASE:
			RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOF, ENABLE);
		break;
		
		case (uint32_t)GPIOG_BASE:
			RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOG, ENABLE);
		break;
	}
	
	switch((uint8_t)mode)
	{
		case AIN:
			GPIO_InitStruc.GPIO_Mode = GPIO_Mode_AIN;
		break;
		
		case IN_FLOATING:
			GPIO_InitStruc.GPIO_Mode = GPIO_Mode_IN_FLOATING;
		break;
		
		case IPD:
			GPIO_InitStruc.GPIO_Mode = GPIO_Mode_IPD;
		break;
		
		case IPU:
			GPIO_InitStruc.GPIO_Mode = GPIO_Mode_IPU;
		break;
		
		case Out_OD:
			GPIO_InitStruc.GPIO_Mode = GPIO_Mode_Out_OD;
		break;
		
		case Out_PP:
			GPIO_InitStruc.GPIO_Mode = GPIO_Mode_Out_PP;
		break;
		
		case AF_OD:
			GPIO_InitStruc.GPIO_Mode = GPIO_Mode_AF_OD;
		break;
		
		case AF_PP:
			GPIO_InitStruc.GPIO_Mode = GPIO_Mode_AF_PP;
		break;
		
		default:
			GPIO_InitStruc.GPIO_Mode = GPIO_Mode_IN_FLOATING;
		break;
	}
	GPIO_InitStruc.GPIO_Pin = this->pin;
	GPIO_InitStruc.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(this->port, &GPIO_InitStruc);
}
/*
*@brief		gpio is high
*@param 	none
*@retval 	none
*/
void Gpio::set(void)
{
	this->port->BSRR = this->pin;
}

/*
*@bried		
*/

void Gpio::reset(void)
{
	this->port->BRR = this->pin;
}

/*
*@brief		GPIO�������
*@param		val��1������ߵ�ƽ��0������͵�ƽ
*@retval 	none
*/
void Gpio::write(uint8_t val)
{
	if(val == 0)
		this->port->BRR = this->pin;
	else
		this->port->BSRR = this->pin;
}
/*
*@brief		��ȡ����״̬
*@param		none
*@retval	�������ŵ�ƽ״̬ 1  0
*/
uint8_t Gpio::read(void)
{
	if(this->port->IDR & this->pin)
		return 1;
	return 0;
}
/*
*@brief		GPIO�����ƽ��ת
*@param		none
*@retval	none
*/
void Gpio::toggle(void)
{
	port->ODR ^= this->pin;
}
/*
*@brief		����int			int a = PA0;
*@param		none
*@retval	none		
*/
Gpio::operator int()
{
	return read();
}
/*
*@brief		
*@param
*@retval	
*/
int Gpio::operator =(Gpio&)
{
	return read();
}

/*
*@brief		���� = ,	
*@param		
*@retval	*this
*/
Gpio Gpio::operator =(int value)
{
	write(value);
	return *this;
}






