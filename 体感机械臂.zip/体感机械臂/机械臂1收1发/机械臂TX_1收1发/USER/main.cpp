#include "func.h"


int main()
{
	setup();	
	while(1)
	{
		task();
	}
}

