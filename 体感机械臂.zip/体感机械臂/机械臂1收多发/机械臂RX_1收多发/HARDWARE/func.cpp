#include "func.h"
/*
MPU6050��1.AD0------PA15
				 2.INT------PB4
				 3.SCL------PB6
				 4.SDA------PB7		
NRF24L01: 1.IRQ-------PA3
					2.MOSI------PB15
					3.CSN-------PA2
					4.MISO------PB14
					5.SCK-------PB13
					6.CE--------PA1			
����ķ�ƵΪ2000��720		
���ݴ�۵ĽǶ���ȷ��С�۵ĽǶȷ�Χ
*/

extern uint8_t rx_Buf0[32];
extern uint8_t rx_Buf1[32];
extern uint8_t rx_Buf2[32];
extern uint8_t rx_Buf3[32];
extern uint8_t rx_Buf4[32];
extern uint8_t rx_Buf5[32];

#define Filter_Num 100



Timer timer3(TIM3);
Key key_claw(&PE2, IPU);

_filter 		filter_data;
_filter 		raw_data;
_servo_ang	servo_ang;


static int abs_1(int p)
{
    return p > 0 ? p : -p;
}

void Slide_Filter(_filter *filter_in, _filter *filter_out)
{
	static int16_t Filter_ax[Filter_Num],Filter_ay[Filter_Num],Filter_az[Filter_Num],Filter_gx[Filter_Num],Filter_gy[Filter_Num],Filter_gz[Filter_Num];
	static uint8_t Filter_count;
	int32_t Filter_sum_ax=0,Filter_sum_ay=0,Filter_sum_az=0,Filter_sum_gx=0,Filter_sum_gy=0,Filter_sum_gz=0;
	uint8_t i=0;
	
	Filter_ax[Filter_count] = filter_in->aacx;
	Filter_ay[Filter_count] = filter_in->aacy;
	Filter_az[Filter_count] = filter_in->aacz;
	Filter_gx[Filter_count] = filter_in->gyrox;
	Filter_gy[Filter_count] = filter_in->gyroy;
	Filter_gz[Filter_count] = filter_in->gyroz;
	
	for(i=0;i<Filter_Num;i++)
	{
		Filter_sum_ax += Filter_ax[i];
		Filter_sum_ay += Filter_ay[i];
		Filter_sum_az += Filter_az[i];
		Filter_sum_gx += Filter_gx[i];
		Filter_sum_gy += Filter_gy[i];
		Filter_sum_gz += Filter_gz[i];
	}	
	
	filter_out->aacx = Filter_sum_ax / Filter_Num;
	filter_out->aacy = Filter_sum_ay / Filter_Num;
	filter_out->aacz = Filter_sum_az / Filter_Num;
	filter_out->gyrox = Filter_sum_gx / Filter_Num;
	filter_out->gyroy = Filter_sum_gy / Filter_Num;
	filter_out->gyroz = Filter_sum_gz / Filter_Num;
	
	Filter_count++;
	if(Filter_count == Filter_Num)
		Filter_count=0;
}

void setup()
{
	yg_init();
	arm_init(2000, 720);//��ʼ��arm
//	timer3.init(1000);//1KHZ
	NRF24L01_Init();
	while(NRF24L01_Check())//���NRF24L01�Ƿ����
	{
		delay_ms(10);
	}
	NRF24L01_RX_Mode();
	//WWDG_Init(0X7F, 0X5F, WWDG_Prescaler_8);
}

void task()
{
	if(NRF24L01_RxPackets() == 0)
	{
		if(rx_Buf0[0] == 'A' && rx_Buf0[1] == 'A')//С��
		{
			servo_ang.turntable = rx_Buf0[2] << 8 | rx_Buf0[3];//x
			servo_ang.small = rx_Buf0[4] << 8 | rx_Buf0[5];//y arm_small
			//		servo_ang.z = rx_buf[4] << 8 | rx_buf[5];
			servo_ang.claw = rx_Buf0[8] << 8 | rx_Buf0[9];
		}
		if(rx_Buf1[0] == 'B' && rx_Buf1[1] == 'B')//���
		{
			servo_ang.big = rx_Buf1[2] << 8 | rx_Buf1[3];//y  arm_big
		}
	}
	/*//���Ʋ���(��һ�ε�ʱ��Ŀ����㷨��)
	if(servo_ang.big>= 0 && servo_ang.big<=30)
	{
		servo_ang.small_min = 175;
		servo_ang.small_max = 180;
		if(servo_ang.small <= servo_ang.small_min)
		servo_ang.small = servo_ang.small_min;
		else if(servo_ang.small >= servo_ang.small_max)
		servo_ang.small = servo_ang.small_max;
	}
	else
	{	//min = 180 - angle + 5
		//max = 180 - angle + 35
		servo_ang.small_min = 185 - servo_ang.big;
		servo_ang.small_max = 215 - servo_ang.big;
		if(servo_ang.small <= servo_ang.small_min)
		servo_ang.small = servo_ang.small_min;
		else if(servo_ang.small >= servo_ang.small_max)
		servo_ang.small = servo_ang.small_max;
	}*/
	
	//���Ʋ���(���µĿ����㷨)
//	servo_ang.small += 60;
//	if(servo_ang.small >= 155)
//	{
//		servo_ang.small = 155;
//	}
//	else if(servo_ang.small <= 70)
//	{
//		servo_ang.small = 70;
//	}
	
	
	if(servo_ang.big <= 104)
	{
		servo_ang.big = 104;
		servo_ang.small = 155;
	}
	else if(servo_ang.big >= 170)
	{
		servo_ang.small = 155;
	}
	else if(servo_ang.big >= 104 && servo_ang.big <= 170)
	{
		servo_ang.small_max = 155;
		servo_ang.small_min = 240 - servo_ang.big;
		if(servo_ang.small <= servo_ang.small_min)
		servo_ang.small = servo_ang.small_min;
		else if(servo_ang.small >= servo_ang.small_max)
		servo_ang.small = servo_ang.small_max;
	}
//	else if(servo_ang.big >= 160 && servo_ang.big <= 180)
//	{
//		servo_ang.small_max = 155;
//		servo_ang.small_min = 70;
//		
//		if(servo_ang.small <= servo_ang.small_min)
//		servo_ang.small = servo_ang.small_min;
//		else if(servo_ang.small >= servo_ang.small_max)
//		servo_ang.small = servo_ang.small_max;
//	}
	
	arm_big.servo_control(servo_ang.big);
	arm_small.servo_control(servo_ang.small);
	arm_turntable.servo_control(servo_ang.turntable);
	arm_claw.servo_control(servo_ang.claw);
}













