#ifndef __YG_TIMER_H
#define __YG_TIMER_H
#ifdef	__cplusplus
extern "C"{
#endif

#include "yg.h"
	
extern uint32_t	tim3Count;
extern uint32_t 	sign;

class Timer
{
	public:
		Timer(TIM_TypeDef *TIMx);//Timer 	timer(TIM1)
		void init(uint16_t period, uint16_t prescaler);//��ʼ����ʱ��init(1000000 / 1000, 72);//1000HZ
		void init(uint16_t period);//��ʼ����ʱ��	init(1);//1HZ
		void start();//��ʱ��ʹ��
		void stop();//��ʱ��ʧ��
	private:
		void base_init(uint16_t period, uint16_t prescaler);//
		TIM_TypeDef *TIMx;
		uint8_t	nvic_ch;			
};	

#ifdef __cplusplus
}
#endif

#endif

//extern "C" void TIM3_IRQHandler(void)
//{
//	if(TIM_GetITStatus(TIM3, TIM_IT_Update) == SET)
//	{
//		PC2.toggle();
//		TIM_ClearITPendingBit(TIM3, TIM_IT_Update);
//	}
//}

