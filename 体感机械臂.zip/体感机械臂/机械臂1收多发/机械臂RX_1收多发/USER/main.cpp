#include "func.h"

Pwm pwm1(&PA7);

int main()
{
	setup();
	servo_ang.big = 150;
	servo_ang.small = 100;
	servo_ang.turntable = 90;
	servo_ang.claw = 90;
//	pwm1.init(1000000 / 1000, 72);
	while(1)
	{
		
//		if(servo_ang.big <= 90)
//		{
//			servo_ang.small = 155;
//		}
//	else if(servo_ang.big >= 90 && servo_ang.big <= 150)
//	{
//		servo_ang.small_max = 155;
//		servo_ang.small_min = 240 - servo_ang.big;
//		if(servo_ang.small <= servo_ang.small_min)
//		servo_ang.small = servo_ang.small_min;
//		else if(servo_ang.small >= servo_ang.small_max)
//		servo_ang.small = servo_ang.small_max;
//	}
//	else if(servo_ang.big >= 160 && servo_ang.big <= 180)
//	{
//		servo_ang.small_max = 155;
//		servo_ang.small_min = 70;
//		
//		if(servo_ang.small <= servo_ang.small_min)
//		servo_ang.small = servo_ang.small_min;
//		else if(servo_ang.small >= servo_ang.small_max)
//		servo_ang.small = servo_ang.small_max;
//		
//	}
//		
//		arm_big.servo_control(servo_ang.big);
//		arm_small.servo_control(servo_ang.small);
//		arm_turntable.servo_control(servo_ang.turntable);
//		arm_claw.servo_control(servo_ang.claw);
		task();
//		delay_ms(1);
	}
}

