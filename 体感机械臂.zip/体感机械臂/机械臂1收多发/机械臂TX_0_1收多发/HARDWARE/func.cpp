#include "func.h"
/*
MPU6050��1.AD0------PA15
				 2.INT------PB4
				 3.SCL------PB6
				 4.SDA------PB7		
NRF24L01: 1.IRQ-------PA3
					2.MOSI------PB15
					3.CSN-------PA2
					4.MISO------PB14
					5.SCK-------PB13
					6.CE--------PA1	
��е�۷��Ͷ�				
С�۷����
��Ҫ���䣺1.claw
					2.arm_small
					3.arm_turntable
ǰ������λ������
*/

uint8_t tx_Buf0[32] = { 'A', 'A' };

#define Filter_Num 100


Key key_claw(&PA5, IPU);

_filter 		filter_data;//�˲�֮�������
_filter 		raw_data;//ԭʼ����
_servo_ang	servo_ang;

int16_t abs(int16_t p)
{
    return p>0?p:-p;
}

void Slide_Filter(_filter *filter_in, _filter *filter_out)
{
	static int16_t Filter_ax[Filter_Num],Filter_ay[Filter_Num],Filter_az[Filter_Num];//,Filter_gx[Filter_Num],Filter_gy[Filter_Num],Filter_gz[Filter_Num];
	static uint8_t Filter_count;
	int32_t Filter_sum_ax=0,Filter_sum_ay=0,Filter_sum_az=0;//,Filter_sum_gx=0,Filter_sum_gy=0,Filter_sum_gz=0;
	uint8_t i=0;
	
	Filter_ax[Filter_count] = filter_in->aacx;
	Filter_ay[Filter_count] = filter_in->aacy;
	Filter_az[Filter_count] = filter_in->aacz;
//	Filter_gx[Filter_count] = filter_in->gyrox;
//	Filter_gy[Filter_count] = filter_in->gyroy;
//	Filter_gz[Filter_count] = filter_in->gyroz;
	
	for(i=0;i<Filter_Num;i++)
	{
		Filter_sum_ax += Filter_ax[i];
		Filter_sum_ay += Filter_ay[i];
		Filter_sum_az += Filter_az[i];
//		Filter_sum_gx += Filter_gx[i];
//		Filter_sum_gy += Filter_gy[i];
//		Filter_sum_gz += Filter_gz[i];
	}	
	
	filter_out->aacx = Filter_sum_ax / Filter_Num;
	filter_out->aacy = Filter_sum_ay / Filter_Num;
	filter_out->aacz = Filter_sum_az / Filter_Num;
//	filter_out->gyrox = Filter_sum_gx / Filter_Num;
//	filter_out->gyroy = Filter_sum_gy / Filter_Num;
//	filter_out->gyroz = Filter_sum_gz / Filter_Num;
	
	Filter_count++;
	if(Filter_count == Filter_Num)
		Filter_count=0;
}

void setup()
{
	yg_init();

	MPU_Init();//��ʼ��MPU6050
	while(mpu_dmp_init())
 	{
		delay_ms(10);
	}
	NRF24L01_Init();
	while(NRF24L01_Check())//���NRF24L01�Ƿ����
	{
		delay_ms(10);
	}
	NRF24L01_TX_Mode();
	//WWDG_Init(0X7F, 0X5F, WWDG_Prescaler_8);
}

void task()
{
	////	MPU_Get_Gyroscope(&raw_data.gyrox, &raw_data.gyroy, &raw_data.gyroz);//get gyro
	MPU_Get_Accelerometer(&raw_data.aacx, &raw_data.aacy, &raw_data.aacz);//get aac
	
	Slide_Filter(&raw_data, &filter_data);//slide filter
	//��Χ0-180��
	servo_ang.x = abs(MPU_GetAngle(filter_data.aacx, filter_data.aacy, filter_data.aacz, 1) / 10 - 90);
	servo_ang.y = abs(MPU_GetAngle(filter_data.aacx, filter_data.aacy, filter_data.aacz, 2) / 10 + 90);
	servo_ang.z = MPU_GetAngle(filter_data.aacx, filter_data.aacy, filter_data.aacz, 0) / 10 + 90;
	
	if(key_claw.key_press() == PRESS)
	{
		delay_ms(10);
		servo_ang.claw = 35;
//		arm_claw.servo_control(35);
	}
	else
	{
		delay_ms(10);
		servo_ang.claw = 80;
//		arm_claw.servo_control(80);
	}
	
	tx_Buf0[2] = (servo_ang.x >> 8) & 0xff;//arm_turntable
	tx_Buf0[3] = servo_ang.x & 0xff;
	tx_Buf0[4] = (servo_ang.y >> 8) & 0xff;//arm_small
	tx_Buf0[5] = servo_ang.y & 0xff;
	tx_Buf0[6] = (servo_ang.z >> 8) & 0xff;//no use
	tx_Buf0[7] = servo_ang.z & 0xff;
	tx_Buf0[8] = (servo_ang.claw >> 8) & 0xff;//arm_claw
	tx_Buf0[9] = servo_ang.claw & 0xff;
	
	
	NRF24L01_TxPacket(tx_Buf0);
}













